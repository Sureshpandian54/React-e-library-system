export const registerLabel={
    firstName:"firstName cannot be empty",
    lastName:"lastName cannot be empty",
    email:"email cannot be empty",
    password:"password cannot be empty",
    validationMatch:"email and password not match"
}